﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace AppAdministrativaHort
{
    /// <summary>
    /// Lógica de interacción para wndAgregarUsuari.xaml
    /// </summary>
    public partial class wndAgregarUsuari : Window
    {
        private bool editar;
        private Usuaris item;

        public wndAgregarUsuari()
        {
            InitializeComponent();
        }

        public wndAgregarUsuari(bool editar, Usuaris item)
        {
            InitializeComponent();
            this.editar = editar;
            this.item = item;

            tbHoras.Text = item.Horas;
            tbID.Text = item.Id;
            tbNom.Text = item.Nom;
            tbFamilia.Text = item.Familia;
            tbContrasenya.Text = item.Contrasenya;
            tbHorts.Text = item.Horts;

            if (item.Actiu == "True")
            {
                chkActiu.IsChecked = true;
            }
            if (item.Universal == "True")
            {
                chkUniversal.IsChecked = true;
            }
            if (item.Local == "True")
            {
                chkLocal.IsChecked = true;
            }
            if (item.compost == "True")
            {
                chkCompost.IsChecked = true;
            }

        }

        private void btnSeguent_Click(object sender, RoutedEventArgs e)
        {
            string connStr = "server=localhost;user=root;database=projectehort;port=3306;";
            string actiu;
            string compst;
            string universal;
            string local;
            if (chkActiu.IsChecked == true)
            {
                actiu = "1";
            }
            else
            {
                actiu = "0";
            }
            if (chkCompost.IsChecked == true)
            {
                compst = "1";
            }
            else
            {
                compst = "0";
            }
            if (chkLocal.IsChecked == true)
            {
                local = "1";
            }
            else
            {
                local = "0";
            }
            if (chkUniversal.IsChecked == true)
            {
                universal = "1";
            }
            else
            {
                universal = "0";
            }
            using (MySqlConnection connection = new MySqlConnection(connStr))
            {
                connection.Open();
                if (!editar)
                {
                    try
                    {
                        MySqlCommand command = new MySqlCommand();
                        command.Connection = connection;
                        command.CommandText = "INSERT INTO usuaris (Horts_Afiliats, id_usuari, Nom_usuari, Contrasenya, Familia, Horas_Realitzadas, Administrador_local, Administrador_Universal, Porta_Compost, Actiu)" +
                            "Values (@horts, @id, @Nom, @Contrasenya, @Familia, @Horas, @local, @universal, @compost, @actiu)";
                        command.Parameters.AddWithValue("@id", tbID.Text);
                        command.Parameters.AddWithValue("@horts", tbHorts.Text);
                        command.Parameters.AddWithValue("@Nom", tbNom.Text);
                        command.Parameters.AddWithValue("@Contrasenya", tbContrasenya.Text);
                        command.Parameters.AddWithValue("@Familia", tbFamilia.Text);
                        command.Parameters.AddWithValue("@Horas", tbHoras.Text);
                        command.Parameters.AddWithValue("@local", local);
                        command.Parameters.AddWithValue("@universal", universal);
                        command.Parameters.AddWithValue("@compost", compst);
                        command.Parameters.AddWithValue("@actiu", actiu);
                        command.ExecuteNonQuery();

                    }
                    catch (Exception ex)
                    {

                        Console.WriteLine(ex.ToString());
                    }
                }
                else
                {
                    try
                    {
                        MySqlCommand command = new MySqlCommand();
                        command.Connection = connection;
                        command.CommandText = "UPDATE usuaris " +
                            "SET Horts_Afiliats = @horts, id_usuari = @id, Nom_usuari = @Nom, Contrasenya = @Contrasenya, Familia = @Familia, Horas_Realitzadas = @Horas, Administrador_local = @local, Administrador_Universal = @universal, Porta_Compost = @compost, Actiu = @actiu " +
                            "WHERE Nom_usuari = @NomOrig AND  Contrasenya = @ContOrg";
                        command.Parameters.AddWithValue("@id", tbID.Text);
                        command.Parameters.AddWithValue("@horts", tbHorts.Text);
                        command.Parameters.AddWithValue("@Nom", tbNom.Text);
                        command.Parameters.AddWithValue("@Contrasenya", tbContrasenya.Text);
                        command.Parameters.AddWithValue("@Familia", tbFamilia.Text);
                        command.Parameters.AddWithValue("@Horas", tbHoras.Text);
                        command.Parameters.AddWithValue("@local", local);
                        command.Parameters.AddWithValue("@universal", universal);
                        command.Parameters.AddWithValue("@compost", compst);
                        command.Parameters.AddWithValue("@actiu", actiu);
                        command.Parameters.AddWithValue("@NomOrig", item.Nom);
                        command.Parameters.AddWithValue("@ContOrg", item.Contrasenya);
                        command.ExecuteNonQuery();

                    }
                    catch (Exception ex)
                    {

                        Console.WriteLine(ex.ToString());
                    }
                }


                connection.Close();
            }
        }
    }
}

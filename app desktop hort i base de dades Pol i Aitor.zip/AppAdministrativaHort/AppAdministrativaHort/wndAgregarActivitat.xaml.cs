﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace AppAdministrativaHort
{
    /// <summary>
    /// Lógica de interacción para wndAgregarActivitat.xaml
    /// </summary>
    public partial class wndAgregarActivitat : Window
    {
        private horari item;
        private bool editar;

        public wndAgregarActivitat()
        {
            InitializeComponent();
        }

        public wndAgregarActivitat(bool editar, horari item)
        {
            InitializeComponent();
            this.editar = editar;
            this.item = item;
            string[] activitat = item.Activitat.Split(';');
            tbData.Text = activitat[1];
            tbLlavors.Text = activitat[0];
            tbHora.Text = activitat[2];
            tbPanell.Text = item.Panell;
            tbHort.Text = item.Hort;
        }

        private void btnSeguent_Click(object sender, RoutedEventArgs e)
        {
            string connStr = "server=localhost;user=root;database=projectehort;port=3306;";

            using (MySqlConnection connection = new MySqlConnection(connStr))
            {
                connection.Open();
                if (!editar)
                {
                    try
                    {
                        MySqlCommand command = new MySqlCommand();
                        command.Connection = connection;
                        command.CommandText = "INSERT INTO activitats ( Nom_Hort, id_panell, Descripcio_Activitat)" +
                            "Values (@hort, @id_panell, @desc)";
                        command.Parameters.AddWithValue("@hort", tbHort.Text);
                        command.Parameters.AddWithValue("@id_panell", tbPanell.Text);
                        command.Parameters.AddWithValue("@desc", tbLlavors.Text + ";" + tbHora.Text +";" + tbData.Text);
                       
                        command.ExecuteNonQuery();

                    }
                    catch (Exception ex)
                    {

                        Console.WriteLine(ex.ToString());
                    }
                }
                else
                {
                    try
                    {
                        MySqlCommand command = new MySqlCommand();
                        command.Connection = connection;
                        command.CommandText = "UPDATE activitats " +
                            "SET Nom_Hort = @hort, id_panell = @id_panell, Descripcio_Activitat = @desc " +
                            "WHERE id_panell = @id_panellOrg AND  Nom_Hort = @HortOrg";
                        command.Parameters.AddWithValue("@hort", tbHort.Text);
                        command.Parameters.AddWithValue("@id_panell", tbPanell.Text);
                        command.Parameters.AddWithValue("@desc", tbLlavors.Text + ";" + tbHora.Text + ";" + tbData.Text);
                        command.Parameters.AddWithValue("@HortOrg", item.Hort);
                        command.Parameters.AddWithValue("@id_panellOrg", item.Panell);
                        command.ExecuteNonQuery();

                    }
                    catch (Exception ex)
                    {

                        Console.WriteLine(ex.ToString());
                    }
                }


                connection.Close();
            }
        }
    }
}

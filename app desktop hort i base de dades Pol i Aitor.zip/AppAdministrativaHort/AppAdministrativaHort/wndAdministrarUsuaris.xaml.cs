﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace AppAdministrativaHort
{
    /// <summary>
    /// Lógica de interacción para wndAdministrarUsuaris.xaml
    /// </summary>
    /// 
    public class Usuaris
    {
        public string Familia { get; set; }
        public string Nom { get; set; }
        public string compost { get; set; }
        public string Actiu { get; set; }
        public string Horas { get; set; }
        public string Universal { get; set; }
        public string Local { get; set; }
        public string Horts { get; set; }
        public string Id { get; set; }
        public string Contrasenya { get; set; }
    }

    public partial class wndAdministrarUsuaris : Window
    {
        List<Usuaris> quantitats = new List<Usuaris>();
        bool editar = false;
        public wndAdministrarUsuaris()
        {
            InitializeComponent();
            string connStr = "server=localhost;user=root;database=projectehort;port=3306;";
            using (MySqlConnection connection = new MySqlConnection(connStr))
            {

                connection.Open();
                try
                {
                    MySqlCommand command = new MySqlCommand();
                    command.Connection = connection;
                    command.CommandText = "SELECT * FROM usuaris";
                    MySqlDataReader rdr = command.ExecuteReader();
                    while (rdr.Read())
                    {
                        Usuaris comp = new Usuaris();
                        comp.Familia = rdr[4].ToString();
                        comp.Nom = rdr[2].ToString();
                        comp.compost = rdr[8].ToString();
                        comp.Actiu = rdr[9].ToString();
                        comp.Horas = rdr[5].ToString();
                        comp.Universal = rdr[7].ToString();
                        comp.Local = rdr[6].ToString();
                        comp.Horts = rdr[0].ToString();
                        comp.Id = rdr[1].ToString();
                        comp.Contrasenya = rdr[3].ToString();
                        quantitats.Add(comp);

                    }
                    rdr.Close();
                }
                catch (Exception ex)
                {

                    Console.WriteLine(ex.ToString());
                }

                connection.Close();
            }
            lstUsuaris.ItemsSource = quantitats;
        }

        private void btnAfegir_Click(object sender, RoutedEventArgs e)
        {
            wndAgregarUsuari windowEinas = new wndAgregarUsuari();
            windowEinas.ShowDialog();
        }

        private void btnEditar_Click(object sender, RoutedEventArgs e)
        {
            Usuaris item = (Usuaris)lstUsuaris.SelectedItem;
            Usuaris comp = new Usuaris();
            string connStr = "server=localhost;user=root;database=projectehort;port=3306;";
            using (MySqlConnection connection = new MySqlConnection(connStr))
            {

                connection.Open();
                try
                {
                    MySqlCommand command = new MySqlCommand();
                    command.Connection = connection;
                    command.CommandText = "SELECT * FROM usuaris WHERE Nom_usuari = @nom AND id_usuari = @id";
                    command.Parameters.AddWithValue("@nom", item.Nom);
                    command.Parameters.AddWithValue("@id",item.Id);
                    MySqlDataReader rdr = command.ExecuteReader();
                    while (rdr.Read())
                    {
                        
                        comp.Familia = rdr[4].ToString();
                        comp.Nom = rdr[2].ToString();
                        comp.compost = rdr[8].ToString();
                        comp.Actiu = rdr[9].ToString();
                        comp.Horas = rdr[5].ToString();
                        comp.Universal = rdr[7].ToString();
                        comp.Local = rdr[6].ToString();
                        comp.Horts = rdr[0].ToString();
                        comp.Id = rdr[1].ToString();
                        comp.Contrasenya = rdr[3].ToString();
                   

                    }
                    rdr.Close();
                }
                catch (Exception ex)
                {

                    Console.WriteLine(ex.ToString());
                }

                connection.Close();
            }




            wndAgregarUsuari windowEinas = new wndAgregarUsuari(editar, comp);
            windowEinas.ShowDialog();
        }

        private void lstUsuaris_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            editar = true;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Usuaris item = (Usuaris)lstUsuaris.SelectedItem;


            string connStr = "server=localhost;user=root;database=projectehort;port=3306;";
            using (MySqlConnection connection = new MySqlConnection(connStr))
            {

                connection.Open();
                try
                {
                    MySqlCommand command = new MySqlCommand();
                    command.Connection = connection;
                    command.CommandText = "DELETE FROM usuaris WHERE Nom_usuari = @nom AND id_usuari = @id";
                    command.Parameters.AddWithValue("@nom", item.Nom);
                    command.Parameters.AddWithValue("@id", item.Id);
                    command.ExecuteNonQuery();
                }
                catch (Exception ex)
                {

                    Console.WriteLine(ex.ToString());
                }

                connection.Close();
            }
        }
    }
}

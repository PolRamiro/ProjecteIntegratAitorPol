﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace AppAdministrativaHort
{
    /// <summary>
    /// Lógica de interacción para wndAgregarEina.xaml
    /// </summary>
    public partial class wndAgregarEina : Window
    {
        string hort = "girona";
        private bool editar = false;
        private eines item;
        private Usuaris item1;

        public wndAgregarEina()
        {
            InitializeComponent();
        }
     

        public wndAgregarEina(bool editar, eines item)
        {
            InitializeComponent();
            this.editar = editar;
            this.item = item;
            tbNom.Text = item.Nom;
            tbQuantitat.Text = item.quantitat;
            tbUsuari.Text = item.Usuari;
            tbHort.Text = item.Hort;
            tbId.Text = item.ID;

        }

       

        private void tbNom_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void btnSeguent_Click(object sender, RoutedEventArgs e)
        {
            string connStr = "server=localhost;user=root;database=projectehort;port=3306;";
            
            using (MySqlConnection connection = new MySqlConnection(connStr))
            {
                connection.Open();
                if (!editar) {
                    try
                    {
                        MySqlCommand command = new MySqlCommand();
                        command.Connection = connection;
                        command.CommandText = "INSERT INTO einas (Nom, id_einas, quantitat, usuari_Utilitzant, Nom_Hort)" +
                            "Values (@name, @id_Einas, @quantitat, @usuari, @nomHort)";
                        command.Parameters.AddWithValue("@name", tbNom.Text);
                        command.Parameters.AddWithValue("@id_Einas", tbQuantitat.Text);
                        command.Parameters.AddWithValue("@quantitat", tbQuantitat.Text);
                        command.Parameters.AddWithValue("@usuari", tbUsuari.Text);
                        command.Parameters.AddWithValue("@nomHort", tbHort.Text);
                        command.ExecuteNonQuery();

                    }
                    catch (Exception ex)
                    {

                        Console.WriteLine(ex.ToString());
                    }
                }
                else
                {
                    try
                    {
                        MySqlCommand command = new MySqlCommand();
                        command.Connection = connection;
                        command.CommandText = "UPDATE einas " +
                            "SET Nom = @name, id_einas = @id_Einas, quantitat = @quantitat, usuari_Utilitzant = @usuari, Nom_Hort = @nomHort " +
                            "WHERE Nom = @NomOrig AND  Nom_Hort = @HortOrg";
                        command.Parameters.AddWithValue("@name", tbNom.Text);
                        command.Parameters.AddWithValue("@id_Einas", tbQuantitat.Text);
                        command.Parameters.AddWithValue("@quantitat", tbQuantitat.Text);
                        command.Parameters.AddWithValue("@usuari", tbUsuari.Text);
                        command.Parameters.AddWithValue("@nomHort", tbHort.Text);
                        command.Parameters.AddWithValue("@NomOrig", item.Nom);
                        command.Parameters.AddWithValue("@HortOrg", item.Hort);
                        command.ExecuteNonQuery();

                    }
                    catch (Exception ex)
                    {

                        Console.WriteLine(ex.ToString());
                    }
                }
                

                connection.Close();
            }
       }
    }
}

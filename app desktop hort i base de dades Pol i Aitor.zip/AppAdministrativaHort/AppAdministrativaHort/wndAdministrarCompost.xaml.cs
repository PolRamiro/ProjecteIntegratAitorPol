﻿using MySql.Data.MySqlClient;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace AppAdministrativaHort
{
    /// <summary>
    /// Lógica de interacción para wndAdministrarCompost.xaml
    /// </summary>
    /// 

        public class compost
    {
      public  string quantitat { get; set; }
        public string Data { get; set; }
        public string NomHort { get; set; }
    }
    public partial class wndAdministrarCompost : Window
    {
        List<compost> quantitats = new List<compost>();
        bool editar = false;
        public wndAdministrarCompost()
        {
            InitializeComponent();
            string connStr = "server=localhost;user=root;database=projectehort;port=3306;";
            using (MySqlConnection connection = new MySqlConnection(connStr))
            {

                connection.Open();
                try
                {
                    MySqlCommand command = new MySqlCommand();
                    command.Connection = connection;
                    command.CommandText = "SELECT * FROM composts";
                    MySqlDataReader rdr = command.ExecuteReader();
                    while (rdr.Read())
                    {
                        compost comp = new compost();
                        comp.Data = rdr[0].ToString();
                        comp.quantitat = rdr[1].ToString();
                        comp.NomHort = rdr[2].ToString();
                   
                        quantitats.Add(comp);

                    }
                    rdr.Close();
                }
                catch (Exception ex)
                {

                    Console.WriteLine(ex.ToString());
                }

                connection.Close();
            }

            lstCompost.ItemsSource = quantitats;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {

        }

        private void ListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            editar = true;
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            wndAgregarCompost windowCompost = new wndAgregarCompost();
            windowCompost.ShowDialog();
        }

        private void btnEditar_Click(object sender, RoutedEventArgs e)
        {
            compost item = (compost)lstCompost.SelectedItem;
            wndAgregarCompost windowEinas = new wndAgregarCompost(editar, item);
            windowEinas.ShowDialog();
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            compost item = (compost)lstCompost.SelectedItem;


            string connStr = "server=localhost;user=root;database=projectehort;port=3306;";
            using (MySqlConnection connection = new MySqlConnection(connStr))
            {

                connection.Open();
                try
                {
                    MySqlCommand command = new MySqlCommand();
                    command.Connection = connection;
                    command.CommandText = "DELETE FROM composts WHERE  Nom_Hort = @HortOrg";
                   
                    command.Parameters.AddWithValue("@HortOrg", item.NomHort);
                    command.ExecuteNonQuery();
                }
                catch (Exception ex)
                {

                    Console.WriteLine(ex.ToString());
                }

                connection.Close();
            }
        }
    }
}

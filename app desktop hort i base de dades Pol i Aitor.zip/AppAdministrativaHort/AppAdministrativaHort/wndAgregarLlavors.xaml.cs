﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace AppAdministrativaHort
{
    /// <summary>
    /// Lógica de interacción para wndAgregarLlavors.xaml
    /// </summary>
    public partial class wndAgregarLlavors : Window
    {
        private bool editar;
        private llavors item;

        public wndAgregarLlavors()
        {
            InitializeComponent();
        }

        public wndAgregarLlavors(bool editar, llavors item)
        {
            InitializeComponent();
            this.editar = editar;
            this.item = item;
            tbHort.Text = item.NomHort;
            tbNom.Text = item.Nom;
            tbId.Text = item.Id;
            tbQuantitat.Text = item.quantitat;
        }

        private void btnSeguent_Click(object sender, RoutedEventArgs e)
        {
            string connStr = "server=localhost;user=root;database=projectehort;port=3306;";

            using (MySqlConnection connection = new MySqlConnection(connStr))
            {
                connection.Open();
                if (!editar)
                {
                    try
                    {
                        MySqlCommand command = new MySqlCommand();
                        command.Connection = connection;
                        command.CommandText = "INSERT INTO llavors (quantitat, Nom, ID_Llavors, Nom_Hort)" +
                            "Values (@quantitat, @nom, @id, @nomHort)";
                        command.Parameters.AddWithValue("@id", tbId.Text);
                        command.Parameters.AddWithValue("@nomHort", tbHort.Text);
                        command.Parameters.AddWithValue("@quantitat", tbQuantitat.Text);
                        command.Parameters.AddWithValue("@nom", tbNom.Text);
                        command.ExecuteNonQuery();

                    }
                    catch (Exception ex)
                    {

                        Console.WriteLine(ex.ToString());
                    }
                }
                else
                {
                    try
                    {
                        MySqlCommand command = new MySqlCommand();
                        command.Connection = connection;
                        command.CommandText = "UPDATE llavors " +
                            "SET quantitat = @quantitat, Nom = @Nom, ID_Llavors = @id, Nom_Hort = @hort " +
                            "WHERE Nom = @NomOrig AND  Nom_Hort = @HortOrg";
                        command.Parameters.AddWithValue("@id", tbId.Text);
                        command.Parameters.AddWithValue("@hort", tbHort.Text);
                        command.Parameters.AddWithValue("@quantitat", tbQuantitat.Text);
                        command.Parameters.AddWithValue("@nom", tbNom.Text);
                        command.Parameters.AddWithValue("@HortOrg", item.NomHort);
                        command.Parameters.AddWithValue("@NomOrig", item.Nom);
                        command.ExecuteNonQuery();

                    }
                    catch (Exception ex)
                    {

                        Console.WriteLine(ex.ToString());
                    }
                }


                connection.Close();
            }
        }
    }
}

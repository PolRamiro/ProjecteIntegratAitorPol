﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace AppAdministrativaHort
{
    /// <summary>
    /// Lógica de interacción para wndAgregarCompost.xaml
    /// </summary>
    public partial class wndAgregarCompost : Window
    {
        private bool editar = false;
        private compost item;

        public wndAgregarCompost()
        {
            InitializeComponent();
        }

        public wndAgregarCompost(bool editar, compost item)
        {
            InitializeComponent();
            this.editar = editar;
            this.item = item;
            tbData.Text = item.Data;
            tbKg.Text = item.quantitat;
            tbHort.Text = item.NomHort;
        }

        private void btnSeguent_Click(object sender, RoutedEventArgs e)
        {
            string connStr = "server=localhost;user=root;database=projectehort;port=3306;";

            using (MySqlConnection connection = new MySqlConnection(connStr))
            {
                connection.Open();
                if (!editar)
                {
                    try
                    {
                        MySqlCommand command = new MySqlCommand();
                        command.Connection = connection;
                        command.CommandText = "INSERT INTO composts (Data_comprobacio, Quantitat_kg, Nom_Hort)" +
                            "Values (@data, @quantitat, @nomHort)";
                        command.Parameters.AddWithValue("@data", tbData.Text);
                        command.Parameters.AddWithValue("@nomHort", tbHort.Text);
                        command.Parameters.AddWithValue("@quantitat", tbKg.Text);
                        command.ExecuteNonQuery();

                    }
                    catch (Exception ex)
                    {

                        Console.WriteLine(ex.ToString());
                    }
                }
                else
                {
                    try
                    {
                        MySqlCommand command = new MySqlCommand();
                        command.Connection = connection;
                        command.CommandText = "UPDATE composts " +
                            "SET Data_comprobacio = @Data, Quantitat_kg = @kg, Nom_Hort = @hort " +
                            "WHERE  Nom_Hort = @HortOrg";
                        command.Parameters.AddWithValue("@data", tbData.Text);
                        command.Parameters.AddWithValue("@hort", tbHort.Text);
                        command.Parameters.AddWithValue("@kg", tbKg.Text);
                        command.Parameters.AddWithValue("@HortOrg", item.NomHort);
                        command.ExecuteNonQuery();

                    }
                    catch (Exception ex)
                    {

                        Console.WriteLine(ex.ToString());
                    }
                }


                connection.Close();
            }
        }

   
    }
}

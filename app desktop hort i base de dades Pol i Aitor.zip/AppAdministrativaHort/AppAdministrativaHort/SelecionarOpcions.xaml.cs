﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace AppAdministrativaHort
{
    /// <summary>
    /// Lógica de interacción para SelecionarOpcions.xaml
    /// </summary>
    public partial class SelecionarOpcions : Window
    {
        public SelecionarOpcions()
        {
            InitializeComponent();
        }

        private void btnLlavors_Click(object sender, RoutedEventArgs e)
        {
            wndAdministrarLlavors windowLlavors = new wndAdministrarLlavors();
            windowLlavors.ShowDialog();
        }

        private void btnEines_Click(object sender, RoutedEventArgs e)
        {
            wndAdministrarEines windowEinas = new wndAdministrarEines();
            windowEinas.ShowDialog();
        }

        private void btnHort_Click(object sender, RoutedEventArgs e)
        {
            wndHorari windowHorari = new wndHorari();
            windowHorari.ShowDialog();
        }

        private void btnCompost_Click(object sender, RoutedEventArgs e)
        {
            wndAdministrarCompost windoCompost = new wndAdministrarCompost();
            windoCompost.ShowDialog();
        }

        private void btnParcelas_Click(object sender, RoutedEventArgs e)
        {
            wndParcelas windoParcelas = new wndParcelas();
            windoParcelas.ShowDialog();
        }

        private void btnUsuaris_Click(object sender, RoutedEventArgs e)
        {
            wndAdministrarUsuaris windoParcelas = new wndAdministrarUsuaris();
            windoParcelas.ShowDialog();
        }
    }
}

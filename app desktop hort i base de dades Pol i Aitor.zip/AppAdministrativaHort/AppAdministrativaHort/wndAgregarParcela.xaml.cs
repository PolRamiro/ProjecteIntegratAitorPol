﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace AppAdministrativaHort
{
    /// <summary>
    /// Lógica de interacción para wndAgregarParcela.xaml
    /// </summary>
    public partial class wndAgregarParcela : Window
    {
        private string hort;
        private string parcela;
        bool editar = false;

        public wndAgregarParcela()
        {
            InitializeComponent();
        }

        public wndAgregarParcela(string hort, string parcela, bool v)
        {
            InitializeComponent();
            this.hort = hort;
            this.parcela = parcela;
            editar = v;

            string connStr = "server=localhost;user=root;database=projectehort;port=3306;";
            using (MySqlConnection connection = new MySqlConnection(connStr))
            {

                connection.Open();
                try
                {
                    MySqlCommand command = new MySqlCommand();
                    command.Connection = connection;
                    command.CommandText = "SELECT * FROM parcela WHERE NumeroParcela = @parcela AND Nom_Hort = @hort";
                    command.Parameters.AddWithValue("@parcela", parcela);
                    command.Parameters.AddWithValue("@hort", hort);
                    MySqlDataReader rdr = command.ExecuteReader();
                    while (rdr.Read())
                    {
                        tbHort.Text = rdr[0].ToString();
                        tbParcela.Text = rdr[1].ToString();
                        tbLlavors.Text = rdr[2].ToString();
                        tbAmplada.Text = rdr[3].ToString();
                        tbAltura.Text = rdr[4].ToString();



                    }
                    rdr.Close();
                }
                catch (Exception ex)
                {

                    Console.WriteLine(ex.ToString());
                }

                connection.Close();
            }


        }

        private void btnSeguent_Click(object sender, RoutedEventArgs e)
        {
            string connStr = "server=localhost;user=root;database=projectehort;port=3306;";

            using (MySqlConnection connection = new MySqlConnection(connStr))
            {
                connection.Open();
                if (!editar)
                {
                    try
                    {
                        MySqlCommand command = new MySqlCommand();
                        command.Connection = connection;
                        command.CommandText = "INSERT INTO parcela (Nom_Hort, NumeroParcela, Nom_Llavors, Amplada , Altura)" +
                            "Values (@name, @parcela, @llavor, @amplada, @altura)";
                        command.Parameters.AddWithValue("@name", tbHort.Text);
                        command.Parameters.AddWithValue("@parcela", tbParcela.Text);
                        command.Parameters.AddWithValue("@llavor", tbLlavors.Text);
                        command.Parameters.AddWithValue("@amplada", tbAmplada.Text);
                        command.Parameters.AddWithValue("@altura", tbAltura.Text);
                        command.ExecuteNonQuery();

                    }
                    catch (Exception ex)
                    {

                        Console.WriteLine(ex.ToString());
                    }
                }
                else
                {
                    try
                    {
                        MySqlCommand command = new MySqlCommand();
                        command.Connection = connection;
                        command.CommandText = "UPDATE parcela " +
                            "SET Nom_Hort = @name, NumeroParcela = @parcela, Nom_Llavors = @llavor, Amplada = @amplada, Altura = @altura " +
                            "WHERE Nom_Hort = @NomOrig AND  NumeroParcela = @parcelaorg";
                        command.Parameters.AddWithValue("@name", tbHort.Text);
                        command.Parameters.AddWithValue("@parcela", tbParcela.Text);
                        command.Parameters.AddWithValue("@llavor", tbLlavors.Text);
                        command.Parameters.AddWithValue("@amplada", tbAmplada.Text);
                        command.Parameters.AddWithValue("@altura", tbAltura.Text);
                        command.Parameters.AddWithValue("@NomOrig", hort);
                        command.Parameters.AddWithValue("@parcelaorg", parcela);
                        command.ExecuteNonQuery();

                    }
                    catch (Exception ex)
                    {

                        Console.WriteLine(ex.ToString());
                    }
                }


                connection.Close();
            }
        }
    }
}

﻿using MySql.Data.MySqlClient;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace AppAdministrativaHort
{
    /// <summary>
    /// Lógica de interacción para wndHorari.xaml
    /// </summary>
    /// 
    public class horari
    {
        public string Panell { get; set; }
        public string Activitat { get; set; }
        public string Hort { get; set; }
      

    }
    public partial class wndHorari : Window
    {
        ArrayList quantitats = new ArrayList();
        private bool editar;

        public wndHorari()
        {
            InitializeComponent();
            string connStr = "server=localhost;user=root;database=projectehort;port=3306;";
            using (MySqlConnection connection = new MySqlConnection(connStr))
            {

                connection.Open();
                try
                {
                    MySqlCommand command = new MySqlCommand();
                    command.Connection = connection;
                    command.CommandText = "SELECT * FROM activitats";
                    MySqlDataReader rdr = command.ExecuteReader();
                    while (rdr.Read())
                    {
                        horari comp = new horari();
                        comp.Panell = rdr[1].ToString();
                        comp.Activitat = rdr[2].ToString();
                        comp.Hort = rdr[0].ToString();
                       
                        quantitats.Add(comp);

                    }
                    rdr.Close();
                }
                catch (Exception ex)
                {

                    Console.WriteLine(ex.ToString());
                }

                connection.Close();
            }

            lstHorari.ItemsSource = quantitats;
        }

        private void lstHorari_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            editar = true;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            wndAgregarActivitat windowEinas = new wndAgregarActivitat();
             windowEinas.ShowDialog();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            horari item = (horari)lstHorari.SelectedItem;
            wndAgregarActivitat windowEinas = new wndAgregarActivitat(editar, item);
            windowEinas.ShowDialog();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            horari item = (horari)lstHorari.SelectedItem;


            string connStr = "server=localhost;user=root;database=projectehort;port=3306;";
            using (MySqlConnection connection = new MySqlConnection(connStr))
            {

                connection.Open();
                try
                {
                    MySqlCommand command = new MySqlCommand();
                    command.Connection = connection;
                    command.CommandText = "DELETE FROM activitats WHERE id_panell = @panell AND Nom_Hort = @HortOrg";
                    command.Parameters.AddWithValue("@panell", item.Panell);
                    command.Parameters.AddWithValue("@HortOrg", item.Hort);
                    command.ExecuteNonQuery();
                }
                catch (Exception ex)
                {

                    Console.WriteLine(ex.ToString());
                }

                connection.Close();
            }
        }
    }
}

﻿using MySql.Data.MySqlClient;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace AppAdministrativaHort
{
    /// <summary>
    /// Lógica de interacción para wndAdministrarEines.xaml
    /// </summary>
    /// 

    public class eines
    {
        public string quantitat { get; set; }
        public string Nom { get; set; }
        public string Usuari { get; set; }
        public string ID { get; set; }
        public string Hort { get; set; }
    }
    public partial class wndAdministrarEines : Window
    {
        bool editar = false;
       ArrayList quantitats = new ArrayList();

        public wndAdministrarEines()
        {
            InitializeComponent();
           

            string connStr = "server=localhost;user=root;database=projectehort;port=3306;";
            using (MySqlConnection connection = new MySqlConnection(connStr))
            {

                connection.Open();
                try
                {
                    MySqlCommand command = new MySqlCommand();
                    command.Connection = connection;
                    command.CommandText = "SELECT * FROM einas";
                    MySqlDataReader rdr = command.ExecuteReader();
                    while (rdr.Read())
                    {
                         eines comp = new eines();
                         comp.Nom = rdr[0].ToString();
                         comp.ID = rdr[1].ToString();
                         comp.quantitat = rdr[2].ToString();
                        comp.Usuari = rdr[3].ToString();
                        comp.Hort = rdr[4].ToString();
                        quantitats.Add(comp);
                      
                    }
                    rdr.Close();
                }
                catch (Exception ex)
                {

                    Console.WriteLine(ex.ToString());
                }
                
                connection.Close();
            }

                lstEines.ItemsSource = quantitats;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            wndAgregarEina windowEinas = new wndAgregarEina();
            windowEinas.ShowDialog();
        }

        private void lstEines_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            editar = true;
        }

     

        private void btnEditar_Click(object sender, RoutedEventArgs e)
        {
            eines item = (eines)lstEines.SelectedItem;
            wndAgregarEina windowEinas = new wndAgregarEina(editar, item);
            windowEinas.ShowDialog();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            eines item = (eines)lstEines.SelectedItem;


            string connStr = "server=localhost;user=root;database=projectehort;port=3306;";
            using (MySqlConnection connection = new MySqlConnection(connStr))
            {

                connection.Open();
                try
                {
                    MySqlCommand command = new MySqlCommand();
                    command.Connection = connection;
                    command.CommandText = "DELETE FROM einas WHERE Nom = @nom AND Nom_Hort = @HortOrg";
                    command.Parameters.AddWithValue("@nom", item.Nom);
                    command.Parameters.AddWithValue("@HortOrg", item.Hort);
                    command.ExecuteNonQuery();
                }
                catch (Exception ex)
                {

                    Console.WriteLine(ex.ToString());
                }

                connection.Close();
            }

        }
    }
}

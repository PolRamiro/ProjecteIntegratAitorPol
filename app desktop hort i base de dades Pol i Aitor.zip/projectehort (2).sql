-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 23-04-2020 a las 18:07:26
-- Versión del servidor: 10.4.11-MariaDB
-- Versión de PHP: 7.4.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `projectehort`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `activitats`
--

CREATE TABLE `activitats` (
  `Nom_Hort` varchar(50) NOT NULL,
  `id_panell` int(11) NOT NULL,
  `Descripcio_Activitat` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `activitats`
--

INSERT INTO `activitats` (`Nom_Hort`, `id_panell`, `Descripcio_Activitat`) VALUES
('hort municipal girona', 4, 'utilitzar compostatge 14:30 22/7/21'),
('hort municipal girona', 4, 'utilitzar compostatge 14:30 22/7/21'),
('girona prova', 0, 'Plantar llentias;13:00;07/10/20'),
('girona prova', 2, 'Plantar llentias;07/10/20;13:00');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `composts`
--

CREATE TABLE `composts` (
  `Data_comprobacio` varchar(10) NOT NULL,
  `Quantitat_kg` int(11) NOT NULL,
  `Nom_Hort` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `composts`
--

INSERT INTO `composts` (`Data_comprobacio`, `Quantitat_kg`, `Nom_Hort`) VALUES
('10/11/20', 300, 'hort municipal san feliu'),
('10/11/20', 300, 'hort municipal san feliu'),
('23/4/20', 50, 'girona');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `einas`
--

CREATE TABLE `einas` (
  `Nom` varchar(50) NOT NULL,
  `id_einas` int(11) NOT NULL,
  `quantitat` int(11) NOT NULL,
  `usuari_Utilitzant` varchar(50) NOT NULL,
  `Nom_Hort` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `einas`
--

INSERT INTO `einas` (`Nom`, `id_einas`, `quantitat`, `usuari_Utilitzant`, `Nom_Hort`) VALUES
('123123', 1, 1, '1', 'hort municipal girona'),
('123123', 1, 1, '1', 'hort municipal girona');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `hort`
--

CREATE TABLE `hort` (
  `Nom Hort` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `hort`
--

INSERT INTO `hort` (`Nom Hort`) VALUES
('hort municipal girona'),
('hort municipal san feliu');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llavors`
--

CREATE TABLE `llavors` (
  `quantitat` int(11) NOT NULL,
  `Nom` varchar(50) NOT NULL,
  `ID_Llavors` int(11) NOT NULL,
  `Nom_Hort` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `llavors`
--

INSERT INTO `llavors` (`quantitat`, `Nom`, `ID_Llavors`, `Nom_Hort`) VALUES
(59, 'llentia', 1, 'hort municipal girona'),
(40, 'cigrons', 1, 'hort municipal san feliu');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `parcela`
--

CREATE TABLE `parcela` (
  `Nom_Hort` varchar(50) NOT NULL,
  `NumeroParcela` int(11) NOT NULL,
  `Nom_Llavors` varchar(50) NOT NULL,
  `Amplada` int(11) NOT NULL,
  `Altura` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `parcela`
--

INSERT INTO `parcela` (`Nom_Hort`, `NumeroParcela`, `Nom_Llavors`, `Amplada`, `Altura`) VALUES
('hort municipal girona', 3, '1', 500, 500),
('hort municipal san feliu', 4, '1', 300, 400);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuaris`
--

CREATE TABLE `usuaris` (
  `Horts_Afiliats` text NOT NULL,
  `id_usuari` int(11) NOT NULL,
  `Nom_usuari` varchar(50) NOT NULL,
  `Contrasenya` varchar(50) NOT NULL,
  `Familia` varchar(50) NOT NULL,
  `Horas_Realitzadas` int(11) NOT NULL,
  `Administrador_local` tinyint(1) NOT NULL,
  `Administrador_Universal` tinyint(1) NOT NULL,
  `Porta_Compost` tinyint(1) NOT NULL,
  `Actiu` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `usuaris`
--

INSERT INTO `usuaris` (`Horts_Afiliats`, `id_usuari`, `Nom_usuari`, `Contrasenya`, `Familia`, `Horas_Realitzadas`, `Administrador_local`, `Administrador_Universal`, `Porta_Compost`, `Actiu`) VALUES
('hort municipal girona;hort municipal san feliu', 1, 'Aitor Criado', '123456', 'Criado', 22, 0, 0, 0, 1),
('hort municipal girona', 2, 'pere2', '12345', 'Vilanova', 10, 1, 0, 1, 1);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `parcela`
--
ALTER TABLE `parcela`
  ADD UNIQUE KEY `NumeroParcela` (`NumeroParcela`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
